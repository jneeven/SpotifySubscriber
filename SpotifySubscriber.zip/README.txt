SpotifySubscriber tool by Jelmer Neeven (https://github.com/jneeven/SpotifySubscriber).
See GitHub page for instructions, and check periodically for updates.